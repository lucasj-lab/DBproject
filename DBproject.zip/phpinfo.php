echo "<?php phpinfo(); ?>" | sudo tee /var/www/html/DBproject/phpinfo.php
