
<!DOCTYPE html>
<html lang="en">
<body>
    <footer>
    <div class="footer-content">
        <p>&copy; <?php echo date("Y"); ?> Rookie List 2.0 | All rights reserved.</p>
        <nav>
            <ul>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="privacy.php">Privacy Policy</a></li>
            </ul>
        </nav>
    </div>
</footer>
</body>
</html>

  <!-- Add styles and hamburger CSS -->